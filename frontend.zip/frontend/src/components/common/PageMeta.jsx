export default function PageMeta({ title, description }) {
  return null;
}