const Forbidden = () => (
  <div className="p-10 text-center">
    <h1 className="text-3xl font-bold text-red-600 mb-4">403 Forbidden</h1>
    <p className="text-gray-700">Anda tidak memiliki akses ke halaman ini.</p>
  </div>
);

export default Forbidden;
